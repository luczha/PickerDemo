﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
namespace App8
{
    public class MyPicker:Picker
    {
        public MyPicker()
        {

        }
    }
}
